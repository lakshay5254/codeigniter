<?php include_once("header.php");  ?>

<div class="container">
	<div class="jumbotron">
    	<h1><span style="color:rgba(216,44,47,0.68)">About Us</h1>
        <p>Welcome to the BlogSpot</p>
        
        <p style="text-align: justify;">
        For the science geek in everyone, Live Science offers a fascinating window into the
         natural and technological world, delivering comprehensive and compelling news and analysis on everything from 
        dinosaur discoveries, archaeological finds and amazing animals to health, innovation and wearable 
        technology.</p>
	<h2>Mission Statement</h2>
        <p style="text-align: justify;">
        To empower and inspire our readers with the tools needed to understand the world and appreciate 
        its everyday awe.</p>
    <h2>Contact Details</h2>
        <p style="text-align: justify;">Email : lakshay5254@gmail.com</p>
        <p>&nbsp;</p>
		
    
    </div>


</div>

<?php include_once("footer.php");  ?>