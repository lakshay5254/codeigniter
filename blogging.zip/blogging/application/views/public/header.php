<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Articles list</title>
<?= link_tag("assets/css/bootstrap.min.css"); ?> <!-- load,helper(html)making link dynamic so if host changes wont effect

-->
<style>
@media screen and (max-width:760px)  {
	ul li{
		text-align:center;
	}
}

</style>
<link href="https://fonts.googleapis.com/css?family=Bangers" rel="stylesheet">

</head>

<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <?= anchor("user","BlogSpot",['class'=>'navbar-brand']); ?>
    
    </div>

    <div class="collapse navbar-collapse" id="collapse">
 		<?= form_open("user/find",['class'=>"navbar-form navbar-left"]); ?>
      <!--<form class="navbar-form navbar-left" role="search">-->
        <div class="form-group">
          <input name="search" type="text" class="form-control" placeholder="Search">
        </div>
        <button type="submit" class="btn btn-default">Search</button>
     <?=  form_close(); ?>
     	<div class="row">
	     	<ul class="nav navbar-nav">
	     		<li><?=  anchor("user","New Articles"); ?></li>
		      	<li><?= anchor("user/trending","Trending");  ?></li>
		        <li><?= anchor("user/about_us","About Us");  ?></li>
	       </ul>
	       <ul class="nav navbar-nav navbar-right">
	       		 <li><a href="<?= base_url("user/user_login"); ?>">Subscribe</a></li>
	       </ul>
      </div>
    </div>
  </div>
</nav>