
<?php include("header.php"); ?>


<div class="container">
	<h1>All Articles</h1>
    <table class="table">
	<thead>
		<tr>
			<th>Serial No.</th>
			<th>Article</th>
			<th>Date Of Publish</th>
		</tr>
	</thead> 
    <tbody>
    	<?php if($articles):
					$count=$this->uri->segment(3,0);
					foreach($articles as $article):
		?>
        <tr>
            <td><?= ++$count ?></td>
            <td><?= anchor("user/view_article/{$article->id}",$article->title); ?></td>
            <td><?= date('d M y H:i:s', strtotime($article->date)); ?></td>  <!--changing date format converting first strtotime()-->
        </tr>
        <?php 		endforeach;
		else: ?>
        	<tr>
            	<td colspan="3">No Articles Found</td>
            </tr>
		<?php endif; ?>
    </tbody>
</table>
<?= $this->pagination->create_links();   ?>


</div>


<?php include("footer.php"); ?>