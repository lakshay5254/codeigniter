<?php include("header.php"); ?>


<div class="container">
	<h1>All Articles</h1>
    <table class="table">
	<thead>
		<tr>
			<th>Serial No.</th>
			<th>Article</th>
			<th>Date Of Publish</th>
		</tr>
	</thead> 
    <tbody>
    	<?php if($searchResult):
					$count=$this->uri->segment(3,0);
					foreach($searchResult as $sr):
		?>
        <tr>
            <td><?= ++$count ?></td>
            <td><?= anchor("user/view_article/{$sr->id}",$sr->title); ?></td>
            <td><?= date("d M y H:i:s", strtotime($sr->date)); ?></td>
        </tr>
        <?php 		endforeach;
		else: ?>
        	<tr>
            	<td colspan="3">No Articles Found</td>
            </tr>
		<?php endif; ?>
    </tbody>
</table>



</div>


<?php include("footer.php"); ?>