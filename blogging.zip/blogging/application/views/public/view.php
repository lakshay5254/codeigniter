<?php include_once("header.php");  ?>

<div class="container">
    <div class="jumbotron">
    	<h1 style="font-family: 'Bangers', cursive;text-align:center; color:rgba(235,15,18,0.60); "><?= $article->title; ?></h1>
    	<?php if(! is_null($article->image_path)):  ?>
    	<img class="img-thumbnail img-responsive" style="display: block; margin-left: auto; margin-right: auto; " src="<?= $article->image_path; ?>" alt="" width="480" height="318" />	<?php endif;  ?>
    	<blockquote>
          <p><?=  $article->body; ?></p>
          <small>Date and time of publish : <cite title="Source Title"><?= date("d M y H:i:s",strtotime($article->date)); ?></cite></small>
        </blockquote>
      
      <p><a class="btn btn-primary btn-sm">Learn more</a></p>
    </div>
</div>


<?php include_once("footer.php");  ?>