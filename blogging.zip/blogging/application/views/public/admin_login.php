
<?php include("header.php"); ?>

<div class="container">

<?= form_open("admin_login/login",['class'=>'form-horizontal']);  ?> <!--helper:form,giving attributes in array = ['to include a class'=>'class name']-->
  <fieldset>
    <legend>Admin Login Page</legend>
    <?php if($this->session->flashdata("loginerror")):  ?>
    <div class="row">
    <div class="col-lg-offset-2 col-lg-5  alert alert-dismissible alert-danger  ">  
      <button type="button" class="close" data-dismiss="alert">&times;</button>
      <strong>Oh snap!</strong><?= $this->session->flashdata("loginerror"); ?> 
    </div>
    </div>
    <?php endif  ?>
    
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label">Email</label>
      <div class="col-lg-5">
      <?= form_input(['name'=>'username','class'=>'form-control','placeholder'=>'username','value'=>set_value("username")]); ?> <!-- helper:form,for text input,-->
        <!--<input type="text" class="form-control" id="inputEmail" placeholder="Email">-->
      </div>
      <div class="col-lg-5">
      	<?= form_error("username"); ?>
      </div>
    </div>
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label">Password</label>
      <div class="col-lg-5">
         <?= form_password(['name'=>'password','class'=>'form-control','placeholder'=>'password']); ?>   <!--for password-->
        <!--<input type="password" class="form-control" id="inputPassword" placeholder="Password">-->
      </div>
      <div class="col-lg-5">
      	<?= form_error("password"); ?>
      </div>
    </div>
     <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
      	<?= form_reset(['name'=>'reset','class'=>'btn btn-default','value'=>'Reset']); ?>
        <!--<button type="reset" class="btn btn-default">Reset</button>-->
        <?= form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Login']);  ?>
        <!--<button type="submit" class="btn btn-primary">Login</button>-->
      </div>
    </div>
  </fieldset>
</form>
<!--<span> echo validation_errors();  </span>  form validation errors same as form_error, form_errors prints errors acc to name -->
</div>



<?php include("footer.php"); ?>