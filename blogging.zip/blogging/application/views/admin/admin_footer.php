<script src="<?= base_url("assets/js/jquery-3.2.1.min.js"); ?>" ></script> <!-- same as link tag of html helper-->
<script src="<?= base_url("assets/js/bootstrap.min.js"); ?>"> </script>

</body>
</html>