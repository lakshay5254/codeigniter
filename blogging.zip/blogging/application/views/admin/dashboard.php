 <?php include_once("admin_header.php"); ?>

<div class="container">
<div class="row">
	<div class="col-lg-9">
    	<?php if($feedback=$this->session->flashdata("feedback")):  
			$feedback_class=$this->session->flashdata("feedback_class");
		?>
        <div class="row">
        <div class="col-lg-offset-2 col-lg-5  alert alert-dismissible <?=  $feedback_class; ?>  ">  
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Oh snap! </strong><?= $feedback; ?> 
        </div>
        </div>
        <?php endif  ?>
    </div>
	<div class="col-lg-3 ">
    	<a href="<?= base_url("admin/add_article"); ?>" class="btn btn-success">Add Article</a>
    </div>
    
</div>
 
<table class="table">
	<thead>
    	<th>Serial no.</th>
        <th>Article title</th>
        <th>Action</th>
    
    </thead>
	<tbody>
    	<?php if(count($articles)):       //for pagination read 
					$count=$this->uri->segment(3,0); //3rd segment of uri if not return 0
					foreach($articles as $art): ?>
    	<tr>
        	<td><?= ++$count  ?></td>
        	<td><?= $art->title; ?></td>    <!--getting title from object-->
            <td>
            	<?= anchor("admin/edit_article/{$art->id}","edit",['class'=>'btn btn-default']);  ?>
                <!--anchor("path of function with value","parameter name", "[array of class]"-->
                
                <a href="<?= base_url("admin/delete_article/{$art->id}"); ?>" class="btn btn-danger">Delete</a>
            </td>
        </tr>
    	<?php
		    		endforeach;
		else: ?>
        	<tr>
            	<td colspan="3">No Articles Found</td>
            </tr>
		<?php 
		endif;
		
		?>
     
    </tbody>
	
</table>
<!--ul.pagination>(li*3(a))+(li.active(a))-->
<?= $this->pagination->create_links(); ?>

</div>



<?php include_once("admin_footer.php"); ?>