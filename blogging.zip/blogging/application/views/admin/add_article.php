<?php  include_once("admin_header.php");  ?>
<?= form_open_multipart("admin/store_article",['class'=>'form-horizontal']);  ?> <!--helper:form,giving attributes in array = ['to include a class'=>'class name']-->
  <fieldset>
    <legend>Edit Article</legend>
   
    
    <div class="form-group">
      <label for="title" class="col-lg-2 control-label">Title Of Article</label>
      <div class="col-lg-5">
      <?= form_input(['name'=>'title','class'=>'form-control','placeholder'=>'Title','value'=>set_value("title")]); ?> <!-- helper:form,for text input, better it must be same as database name as can use array directly-->
        <!--<input type="text" class="form-control" id="inputEmail" placeholder="Email">-->
      </div>
      <div class="col-lg-5">
      	<?= form_error("title"); ?>
      </div>
    </div>
    <div class="form-group">
      <label for="body" class="col-lg-2 control-label">Body of article</label>
      <div class="col-lg-5">
         <?= form_textarea(['name'=>'body','class'=>'form-control','placeholder'=>'body','value'=>set_value("body")]); ?>   <!--for password-->
        <!--<input type="password" class="form-control" id="inputPassword" placeholder="Password">-->
      </div>
      <div class="col-lg-5">
      	<?= form_error("body"); ?>
      </div>
    </div>
     <div class="form-group">
      <label for="title" class="col-lg-2 control-label">Upload Images</label>
      <div class="col-lg-5">
      <?= form_upload(['name'=>'image','class'=>'form-control']); ?> <!-- helper:form,for text input, better it must be same as database name as can use array directly-->
        <!--<input type="text" class="form-control" id="inputEmail" placeholder="Email">-->
      </div>
      <div class="col-lg-5">
      	<?php if(isset($upload_error)){ echo $upload_error; } ?>
      </div>
    </div>
    <?= form_hidden("user_id",$this->session->userdata("user_id"));  ?>
     <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
      	<?= form_reset(['name'=>'reset','class'=>'btn btn-default','value'=>'Reset']); ?>
        <!--<button type="reset" class="btn btn-default">Reset</button>-->
        <?= form_submit(['name'=>'submit','class'=>'btn btn-primary','value'=>'Submit']);  ?>
        <!--<button type="submit" class="btn btn-primary">Login</button>-->
      </div>
    </div>
   
  </fieldset>
  <?= form_hidden("date", date("Y-m-d H:i:s")); ?>
</form>




<?php  include_once("admin_footer.php");  ?>