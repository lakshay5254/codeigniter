<?php
class Admin_login extends CI_Controller{
	
	public function index(){
		if($this->session->userdata("user_id")){
			return redirect("admin/dashboard"); //if user trying to access login page then move back to dashboard
		}
		$this->load->helper('form');
		$this->load->view("public/admin_login");
		
	}
	
	public function login(){
		
		
		$this->load->library("form_validation");	
		/*$this->form_validation->set_rules("username","User Name","required|max_length[10]|alpha");//rather then setting rules here we can set rules in config>make form_validation.php>see user guide/Saving Sets of Validation Rules to a Config File
		$this->form_validation->set_rules("password","Password","required");  set in config>form_validation*/
		$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>'); //set element that will show error and set class by default <p> shows error
		if($this->form_validation->run("admin_login")){
			
			$username=$this->input->post("username");  // getting post data from , we can use $_post but as we r working in framework so should ustilise framework
			$password=$this->input->post("password");
			$this->load->model("loginmodel");
			$login_id=$this->loginmodel->login_valid($username,$password);//function in login model we created
			if($login_id){  // 0 = false and number more then 0 like 1, 2,3 are true
				//$this->load->library("session"); loaded in autoload //load session set encription key of session in config>config.php encryption
				$this->session->set_userdata("user_id",$login_id);  //setting session
				//$this->load->view("admin/dashboard"); here we directly loading admin view which should be loaded by admin login controller so in place of it we use redirect 
				return redirect("admin/dashboard");   //admin controller dashboard()
			}else{
				$this->session->set_flashdata("loginerror","Username/password doesn't match");
				return redirect("admin_login");
			}
			
			
		}else{
			
			$this->load->view("public/admin_login");
			//echo validation_error();
		}
	}
	
	
	
	public function logout(){
		$this->session->unset_userdata("user_id");
		return redirect("admin_login");
		
	}
}

?>