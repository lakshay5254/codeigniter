<?php
	class Admin extends CI_Controller{
		
		public function dashboard($offset=0){  //recieving offset using get from uri first offset when page loads=0 ,, or we can use $this->uri->segment(3) in place of $offset which will return false or 0 when no offset set 
			//=====pagination starts=======
			//load> make config array with given info, >initialize with array >put limit in get_article>offet will auto set in uri bar get iffset from uri
			$this->load->library("pagination");
			$config=[
						'base_url'=> base_url("admin/dashboard"),
						'per_page'=>5,
						'total_rows'=>$this->articles_model->number_rows(),
						
						//cutomization
						'full_tag_open'=>"<ul class='pagination'>",
						'full_tag_close'=>"</ul>",
						'next_tag_open'=>"<li>",
						'next_tag_close'=>"</li>",
						'prev_tag_open'=>"<li>",
						'prev_tag_close'=>"</li>",
						'num_tag_open'=>'<li>',
						'num_tag_close'=>'</li>',
						'cur_tag_open'=>"<li class='active' ><a>",
						'cur_tag_close'=>'</a></li>'
			
			];
			
			$this->pagination->initialize($config);  //config= any name
			$article=$this->articles_model->get_article($config['per_page'],$offset); //$limit,$offset=where to start
			//==========pagintion end ================
			//loading model in constructor to save loading it again and again
			$this->load->view("admin/dashboard",["articles"=>$article]);  //["array name throught which to access value"=>$value to send]
		}
		
		public function add_article(){
			$this->load->view("admin/add_article");	
		}
		
		// we should use different functions for get and set or for different functions as there is minimal run of code each time
		public function store_article(){
			// form_validation is done in config file, better for multiple files
			//form_validation loaded in constructor
			$config=[									//config file for image upload we can add different keys
					"upload_path"=> "./uploads/",
					"allowed_types"=> "jpeg|png|jpg"
			];
			$this->load->library("upload",$config);
			$this->form_validation->set_error_delimiters('<div class="text-danger">','</div>');
			if($this->form_validation->run('store_article') && $this->upload->do_upload("image")){
				$post=$this->input->post();   //array of all post data rather  then recieving one 
				unset($post['submit']);  //removing submit key value from array 
				$filename=$this->upload->data("file_name");
				$image_path=base_url("uploads/".$filename);
				$post["image_path"]=$image_path;
				$this->flashAndRedirect(
										$this->articles_model->store_article($post),
										"Article Added Successfully",
										"Article Not Added "
										);
				
			}else{
				$upload_error=$this->upload->display_errors();
				$this->load->view('admin/add_article',compact('upload_error'));
			}
		}
		
		public function edit_article($article_id){
			$article=$this->articles_model->find_article($article_id);
			
			
			$this->load->view("admin/edit_article",['article'=>$article]);
			
		}
		
		public function update_article($article_id){
			if($this->form_validation->run("store_article")){
				$updated_article=$this->input->post();
				unset($updated_article["submit"]);
				$this->flashAndRedirect(
										$this->articles_model->update_article($article_id,$updated_article),
										"Article Updated Successfully",
										"Article Not Updated "
										);
	
			}else{
				$this->load->view("admin/edit_article");
				
			}
			
		}
		
		public function delete_article($article_id){
			//exit($article_id);
			$this->flashAndRedirect(
									$this->articles_model->delete_article($article_id),
									"Article Deleted Successfully",
									"Article Not deleted "
									);
		}
		
		public function __construct(){
			parent::__construct();
			if(! $this->session->userdata("user_id")){	//checking if user login or not
				return redirect("admin_login");
			}
			$this->load->model("articles_model");
			$this->load->helper("form");
			$this->load->library("form_validation");
		}
		
		private function flashAndRedirect($successful,$true,$false){  //true= msg to print is true, false=msg to print if false
			if($successful){
				$this->session->set_flashdata("feedback",$true);
				$this->session->set_flashdata("feedback_class","alert-success");
			}else{
				$this->session->set_flashdata("feedback",$false);
				$this->session->set_flashdata("feedback_class","alert-danger");
			}
			return redirect("admin/dashboard");
		}
		
	}

?>