<?php

class User extends CI_Controller{
		
		public function index(){
			
			$this->load->library("pagination");
			$config=[
						'base_url'=> base_url("user/index"),
						'per_page'=> 5,
						'total_rows'=> $this->articles_model->all_num_rows(),
						'full_tag_open'=>"<ul class='pagination'>",
						'full_tag_close'=>"</ul>",
						'next_tag_open'=>'<li>',
						'next_tag_close'=>'</li>',
						'prev_tag_open'=>'<li>',
						'prev_tag_close'=>'</li>',
						'num_tag_open'=>'<li>',
						'num_tag_close'=>'</li>',
						'cur_tag_open'=>'<li class="active"><a>',
						'cur_tag_close'=>'</a></li>'
			
			
			];
			
			$this->pagination->initialize($config);
			$articles=$this->articles_model->all_articles($config["per_page"],$this->uri->segment(3),"date");
		
			$this->load->view("public/articles_list",['articles'=>$articles]);
		
		}
		
		public function find(){
			$find=$this->input->post("search");
			$searchResult=$this->articles_model->search($find);
			$this->load->view("public/searchResult",["searchResult"=>$searchResult]);
				
		}
		
		public function view_article($article_id){
			
			
			if($article=$this->articles_model->view($article_id)){
					
				$this->load->view("public/view",["article"=>$article]);
			}
				
			
		}
		
		public function trending(){

			$this->load->library("pagination");
			$config=[
						'base_url'=> base_url("user/index"),
						'per_page'=> 5,
						'total_rows'=> $this->articles_model->all_num_rows(),
						'full_tag_open'=>"<ul class='pagination'>",
						'full_tag_close'=>"</ul>",
						'next_tag_open'=>'<li>',
						'next_tag_close'=>'</li>',
						'prev_tag_open'=>'<li>',
						'prev_tag_close'=>'</li>',
						'num_tag_open'=>'<li>',
						'num_tag_close'=>'</li>',
						'cur_tag_open'=>'<li class="active"><a>',
						'cur_tag_close'=>'</a></li>'
			
			
			];
			$this->pagination->initialize($config);
			$articles=$this->articles_model->all_articles($config["per_page"],$this->uri->segment(3),"views");
			$this->load->view("public/articles_list",["articles"=>$articles]);
		}
		
		public function about_us(){
			
			$this->load->view("public/about_us");	
		}
		
		public function __construct(){
			parent::__construct();
			$this->load->model("articles_model");
			$this->load->helper("form");
		
		}
}
?>