<?php
	$config = [  
					'admin_login'=>[
										[
											'field'=>'username',
											'lable'=>'User Name',
											'rules'=>'required|max_length[10]|alpha'
										
										
										],
										[
											'field'=>'password',
											'lable'=>'Password',
											'rules'=>'required'
										]
					
						],
						
					'store_article'=>[
					
											[
												'field'=>'title',
												'lable'=>'Article Title',
												'rules'=>'required'
										
										
											],
											[
												'field'=>'body',
												'lable'=>'Article Body',
												'rules'=>'required'
											]
					
					
						]
	
	
	
	
	]

?>