<?php

class Articles_model extends CI_model{
	//============admin ===================
	public function get_article($limit,$offset){
		$userid=$this->session->userdata("user_id");
		$query=$this->db->select("title,id")->where("user_id",$userid)->limit($limit,$offset)->get("articles");//where([''=>''])
			//$query->result) return array of objects each object contain each row of table , when need to fetch many articles
			//$query->row() return one object or first row of table, when need only one article
			return $query->result(); 
	}
	
	public function number_rows(){
		$userid=$this->session->userdata("user_id");
		$query=$this->db->select("title,id")->where("user_id",$userid)->get("articles");
		return $query->num_rows();
	}
	
	public function store_article($post){
		return $this->db->insert("articles",$post);  //post= array of 'key'=>'value' without it insert("table",[''=>'']
	}
	
	public function find_article($article_id){
		 $q=$this->db->select("title,body,id")->where('id',$article_id)->get("articles");
		 return $q->row();
	}
	
	public function update_article($article_id,$article){
		return $this->db->update("articles",$article,"id=$article_id");
		
		
	}
	
	public function delete_article($article_id){
		
		return $this->db->delete("articles",["id"=>$article_id]);
	}
	
	//=============users===============
	public function all_num_rows(){
		$query=$this->db->select("id")->get("articles");
		return $query->num_rows();
		
	}
	
	public function all_articles($limit,$offset,$orderby){
		$query=$this->db->select("id,title,body,date")->limit($limit,$offset)->order_by($orderby,"DESC")->get("articles");
		return $query->result();
		
	}
	
	public function search($find){
		$query=$this->db->like("title",$find)->get("articles");
		return $query->result();	
	}
	
	public function view($article_id){
		$query=$this->db->where(["id"=>$article_id])->get("articles");
		$article=$query->row();	
		$this->db->update("articles",["views"=>$article->views+1],"id=$article_id");
		if($query->num_rows()){
			return $article;	
		}else{
			return false;
		}
	}
}

?>