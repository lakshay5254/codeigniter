<?php

class Loginmodel extends CI_model{
	
	public function login_valid(string $username,$password){
		//$q=$this->db->query(sql);  simple query  better to use active record as below
		$q=$this->db->where(['uname'=>$username, 'pword'=>$password])->get("users");
		if($q->num_rows()){
			return $q->row()->id;
		}else{
			return false;
		}
	}
	
}



?>